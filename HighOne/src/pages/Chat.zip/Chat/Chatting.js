import React, { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import {
  Button,
  Col,
  Row,
  UncontrolledTooltip,
  Dropdown,
  DropdownMenu,
  DropdownToggle,
  Form,
  FormGroup,
  Input,
  InputGroup,
} from "reactstrap"
import PerfectScrollbar from "react-perfect-scrollbar"
import "react-perfect-scrollbar/dist/css/styles.css"
import { useDispatch } from "react-redux"
import {
  Timestamp,
  addDoc,
  arrayUnion,
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
} from "firebase/firestore"
import { db } from "./firebase"
import { margin } from "@mui/system"
import { GetAllTeacher } from "apis/ChatsApi"

const Chatting = props => {
  const [messages, setMessages] = useState([])
  const [text, setText] = useState("")
  const [messageBox, setMessageBox] = useState(null)
  const [search_Menu, setsearch_Menu] = useState(false)
  const [usercode, setusercode] = useState("")
  const path = window?.location.pathname.split("/chat/")[1]
  const myuser = JSON.parse(localStorage.getItem("User"))
  const docid = path + "-" + myuser?.payload?.t_code

  const toggleSearch = () => {
    setsearch_Menu(!search_Menu)
  }

  const onKeyPress = e => {
    const { key, value } = e
    if (key === "Enter") {
      setText(value)
      onSend()
    }
  }

  useEffect(() => {
    const q = query(collection(db, "Chatting"))
    const unsubscribe = onSnapshot(q, querySnapshot => {
      let message = []
      querySnapshot.forEach(doc => {
        message.push({ ...doc.data(), id: doc.id })
      })
      setMessages(
        message &&
          message.filter(value => value.id === docid).map(data => data.messages)
      )
      const userId =
        message &&
        message.filter(value => value.id === docid).map(data => data.id)[0]
      setusercode(userId)
      // console.log(message && message.filter(value => value.id === path).map(data => data.id)[0])
      // console.log(path)
      // console.log(userId)
      // console.log(
      //   message.map(e => e.reciveId === usercode && e.reciveId),
      //   "User Id"
      // )
    })

    return () => unsubscribe()
  }, [])

  const onSend = async () => {
    const id = Math.random().toString(36).substring(2, 18)
    // add new field
    // await setDoc(doc(db, "Chatting", usercode), {
    //   messages: arrayUnion({
    //   textMsg: text,
    //   reciveId: usercode,
    //   senderId: usercode,
    //   createdAt: new Date(),
    //   }),
    // })
    // update

    await addDoc(collection(db, "messages"), {
      messages: arrayUnion({
        key: id,
        textMsg: text,
        reciveId: myuser?.payload?.t_code,
        senderId: path,
        createdAt: new Date(),
      }),
    })
    await updateDoc(doc(db, "Chatting", docid), {
      messages: arrayUnion({
        key: id,
        textMsg: text,
        reciveId: myuser?.payload?.t_code,
        senderId: path,
        createdAt: new Date(),
      }),
    })

    setText("")
  }

  const [userData, setUserData] = useState({})
  useEffect(() => {
    getUser()
  }, [userData, path])

  const getUser = async () => {
    const data = {
      t_code: path,
    }
    await GetAllTeacher.GetSingleUser(data)
      .then(({ data }) => setUserData(data.data[0]))
      .catch(err => {
        console.log(err)
      })

    // alert(userData.t_code)
  }

  return (
    <>
      <div className="p-4 border-bottom ">
        <Row>
          <Col md="4" xs="9">
            <h5 className="font-size-15 mb-1">{userData?.t_name}</h5>
            <p className="text-muted mb-0">
              <i
                className={
                  props.active === "Active Now"
                    ? "mdi mdi-circle text-success align-middle me-2"
                    : props.active === "intermediate"
                    ? "mdi mdi-circle text-warning align-middle me-1"
                    : "mdi mdi-circle align-middle me-1"
                }
              />
              {props.active}
            </p>
          </Col>
          <Col md="8" xs="3">
            <ul className="list-inline user-chat-nav text-end mb-0">
              <li className="list-inline-item d-none d-sm-inline-block">
                <Dropdown
                  className="me-1"
                  isOpen={search_Menu}
                  toggle={toggleSearch}
                >
                  <DropdownToggle className="btn nav-btn" tag="a">
                    <i className="bx bx-search-alt-2" />
                  </DropdownToggle>
                  <DropdownMenu className="dropdown-menu-md">
                    <Form className="p-3">
                      <FormGroup className="m-0">
                        <InputGroup>
                          <Input
                            type="text"
                            className="form-control"
                            placeholder="Search ..."
                            aria-label="Recipient's username"
                          />
                          <Button color="primary" type="submit">
                            <i className="mdi mdi-magnify" />
                          </Button>
                        </InputGroup>
                      </FormGroup>
                    </Form>
                  </DropdownMenu>
                </Dropdown>
              </li>
            </ul>
          </Col>
        </Row>
      </div>
      {/*  */}
      <div>
        <div className="chat-conversation p-3">
          <ul className="list-unstyled">
            <PerfectScrollbar
              style={{ height: "470px" }}
              containerRef={ref => setMessageBox(ref)}
            >
              {/* <li>
                <div className="chat-day-title">
                  <span className="title">Today</span>
                </div>
              </li> */}
              {/* Chats yaha hai */}
              {messages &&
                messages.map(
                  item =>
                    item &&
                    item.map(text => (
                      <div key={text.key}>
                        {text.senderId === path ? (
                          <div className="outgoing-chats">
                            <div className="outgoing-chats-img">
                              {/* <img src="user1.png" /> */}
                            </div>
                            <div className="outgoing-msg">
                              <div className="outgoing-chats-msg">
                                <p className="multi-msg">{text.textMsg}</p>
                                {/* <span className="time">{text.createdAt}</span> */}
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="received-chats">
                            <div className="received-chats-img">
                              {/* <img src="user2.png" /> */}
                            </div>
                            <div className="received-msg">
                              <div className="received-msg-inbox">
                                <p>{text.textMsg}</p>
                                {/* <span className="time">{text.createdAt}</span> */}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))
                )}
            </PerfectScrollbar>
          </ul>
        </div>
        <div className="p-3 chat-input-section">
          <Row>
            <Col>
              <div className="position-relative">
                <input
                  type="text"
                  value={text}
                  onKeyPress={onKeyPress}
                  onChange={e => setText(e.target.value)}
                  className="form-control chat-input"
                  placeholder="Enter Message..."
                />
                <div className="chat-input-links">
                  <ul className="list-inline mb-0">
                    <li className="list-inline-item"></li>
                    <li className="list-inline-item">
                      <Link to="#">
                        <i
                          className="mdi mdi-file-image-outline me-1"
                          id="Imagetooltip"
                        />
                        <UncontrolledTooltip
                          placement="top"
                          target="Imagetooltip"
                        >
                          Images
                        </UncontrolledTooltip>
                      </Link>
                    </li>
                    <li className="list-inline-item">
                      <Link to="#">
                        <i
                          className="mdi mdi-file-document-outline"
                          id="Filetooltip"
                        />
                        <UncontrolledTooltip
                          placement="top"
                          target="Filetooltip"
                        >
                          Add Files
                        </UncontrolledTooltip>
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>
            </Col>
            <Col className="col-auto">
              <Button
                type="button"
                color="primary"
                onClick={onSend}
                className="btn btn-primary btn-rounded chat-send"
              >
                <span className="d-none d-sm-inline-block me-2">Send</span>{" "}
                <i className="mdi mdi-send" />
              </Button>
            </Col>
          </Row>
        </div>
      </div>
    </>
  )
}

export default Chatting
