import React, { useEffect, useState } from "react"
import PropTypes from "prop-types"
import { isEmpty, map } from "lodash"
import { Button, Card, Col, Container, Row } from "reactstrap"
import "react-perfect-scrollbar/dist/css/styles.css"
import { useSelector, useDispatch } from "react-redux"
import ChatRoom from "./ChatRoom"
import Chatting from "./Chatting"

const Chat = () => {
  const [users, setUsers] = useState([])
  const [name, setName] = useState("Sarfaraz")
  const [id, setId] = useState("002")

  document.title = "Chat"

  const { chats, groups, contacts, messages } = useSelector(state => ({
    chats: state.chat.chats,
    groups: state.chat.groups,
    contacts: state.chat.contacts,
    messages: state.chat.messages,
  }))

  const [messageBox, setMessageBox] = useState(null)

  useEffect(() => {
    if (!isEmpty(messages)) scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    if (messageBox) {
      messageBox.scrollTop = messageBox.scrollHeight + 1000
    }
  }

  return (
    <React.Fragment>
      <Container fluid className="mt-5 pt-5">
        <Row>
          <Col lg="12">
            <div className="d-lg-flex">
              <ChatRoom />
              <div className="w-100 user-chat">
                <Card >
                  <Chatting name={name} id={id} active={"Active Now"} />
                </Card>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </React.Fragment>
  )
}

Chat.propTypes = {
  chats: PropTypes.array,
  groups: PropTypes.array,
  contacts: PropTypes.array,
  messages: PropTypes.array,
  onGetChats: PropTypes.func,
  onGetGroups: PropTypes.func,
  onGetContacts: PropTypes.func,
  onGetMessages: PropTypes.func,
  onAddMessage: PropTypes.func,
}

export default Chat
