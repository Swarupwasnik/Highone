import React, { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import PerfectScrollbar from "react-perfect-scrollbar"
import avatar1 from "../../assets/images/users/avatar-1.jpg"
import PropTypes from "prop-types"
import classnames from "classnames"

import {
  Button,
  Card,
  Col,
  Container,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Form,
  FormGroup,
  Input,
  InputGroup,
  Nav,
  NavItem,
  NavLink,
  Row,
  TabContent,
  TabPane,
  UncontrolledDropdown,
  UncontrolledTooltip,
} from "reactstrap"
import { GetAllTeacher } from "apis/ChatsApi"
import { addDoc, doc, setDoc, updateDoc } from "firebase/firestore"
import { db } from "./firebase"

const ChatRoom = () => {
  const [activeTab, setactiveTab] = useState("1")
  const [AllUser, setAllUser] = useState([])
  const path = window?.location.pathname.split("/chat/")[1]
  const myuser = JSON.parse(localStorage.getItem("User"))
  const docid = path + "-" + myuser?.payload?.t_code

  const searchUsers = () => {
    var input, filter, ul, li, a, i, txtValue
    input = document.getElementById("search-user")
    filter = input.value.toUpperCase()
    ul = document.getElementById("recent-list")
    li = ul.getElementsByTagName("li")
    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName("a")[0]
      txtValue = a.textContent || a.innerText
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = ""
      } else {
        li[i].style.display = "none"
      }
    }
  }

  const toggleTab = tab => {
    if (activeTab !== tab) {
      setactiveTab(tab)
    }
  }

  useEffect(() => {
    GetAllTeacher.GetAllTeacher()
      .then(res => {
        setAllUser(res.data.teacher)
        console.log(res.data.teacher)
      })
      .catch(err => {
        console.log(err)
      })
  }, [])

  const [userData, setUserData] = useState({})
  useEffect(() => {
    AddFirebase()
  }, [userData])
  
  const AddFirebase = async user => {
    // const data = {
    //   t_code: user,
    // }
    // await GetAllTeacher.GetSingleUser(data)
    //   .then(({ data }) => setUserData(data.data[0]))
    //   .catch(err => {
    //     console.log(err)
    //   })

    // await setDoc(doc(db, "Chatting", docid ), {})
    // alert(userData.t_code)
  }

  return (
    <div className="chat-leftsidebar me-lg-4">
      <div className="search-box chat-search-box pb-3">
        <div className="position-relative">
          <Input
            onKeyUp={searchUsers}
            id="search-user"
            type="text"
            className="form-control"
            placeholder="Search..."
          />
          <i className="bx bx-search-alt search-icon" />
        </div>
      </div>

      <div className="">
        <div className="chat-leftsidebar-nav">
          <Nav pills justified>
            <NavItem>
              <NavLink
                className={classnames({
                  active: activeTab === "1",
                })}
                onClick={() => {
                  toggleTab("1")
                }}
              >
                <i className="bx bx-chat font-size-20 d-sm-none" />
                <span className="d-none d-sm-block">Chat</span>
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({
                  active: activeTab === "2",
                })}
                onClick={() => {
                  toggleTab("2")
                }}
              >
                <i className="bx bx-group font-size-20 d-sm-none" />
                <span className="d-none d-sm-block">Groups</span>
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({
                  active: activeTab === "3",
                })}
                onClick={() => {
                  toggleTab("3")
                }}
              >
                <i className="bx bx-book-content font-size-20 d-sm-none" />
                <span className="d-none d-sm-block">Contacts</span>
              </NavLink>
            </NavItem>
          </Nav>
          <TabContent activeTab={activeTab}>
            <TabPane tabId="3">
              <h5 className="font-size-14 my-3">Contact</h5>
              <div>
                <PerfectScrollbar style={{ height: "70vh" }}>
                  <div className="">
                    {AllUser &&
                      AllUser.map(user => (
                        <Link
                          to={`/chat/${user.t_code}`}
                          key={user.t_code}
                          onClick={() => AddFirebase(user.t_code)}
                        >
                          <div className="d-flex py-2 border-bottom">
                            <div className="align-self-center me-3">
                              <img
                                src={
                                  user.profile_pic_url === ""
                                    ? avatar1
                                    : user.profile_pic_url
                                }
                                className="avatar-xs rounded-circle"
                                alt=""
                              />
                            </div>
                            <div className="flex-grow-1">
                              <h5 className="font-size-15 mt-0 mb-1">
                                {user.t_name
                                  .toLowerCase()
                                  .charAt(0)
                                  .toUpperCase() +
                                  user.t_name.toLowerCase().slice(1)}
                              </h5>
                              <p className="text-muted mb-0">
                                <i className="mdi mdi-circle text-success align-middle me-2" />
                                Active
                              </p>
                            </div>
                            <div className="font-size-11">2.30 pm</div>
                          </div>
                        </Link>
                      ))}
                  </div>
                </PerfectScrollbar>
              </div>
            </TabPane>
          </TabContent>
        </div>
      </div>
    </div>
  )
}

ChatRoom.propTypes = {
  chats: PropTypes.array,
  groups: PropTypes.array,
  contacts: PropTypes.array,
  messages: PropTypes.array,
  onGetChats: PropTypes.func,
  onGetGroups: PropTypes.func,
  onGetContacts: PropTypes.func,
  onGetMessages: PropTypes.func,
  onAddMessage: PropTypes.func,
}

export default ChatRoom
